import xlsxwriter

from django.http import HttpResponse
from avs.models import Av


def export_xls(request):
    pass
